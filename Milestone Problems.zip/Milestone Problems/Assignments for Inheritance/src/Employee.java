
 class Employee extends Person  {
	 double annual_salary=30000;
	 String started_to_work="2000";
	 String National_Ins_no="4568";
	 Employee(){
		 System.out.println("Annual_salary: "+annual_salary+"\n"+"Join_year: "+started_to_work+"\n"+"National_Ins_no: "+National_Ins_no);
	 }
}
