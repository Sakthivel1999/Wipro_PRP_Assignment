class The_Person{
	String Name="sakthi";
}
class The_Student{
	String Work="Studey";
}
class Teacher extends The_Person{
	double salary=25000;
	String subject ="Tamil";
	Teacher(){
		System.out.print("Name="+Name+"\nsalary="+salary+"\nsubject="+subject);
	}
}
class CollegeStudent extends The_Student{
	String year ="2020";
	String major ="Communications";
	CollegeStudent(){
		System.out.print("Work="+Work+"\nyear="+year+"\nmajor="+major);
	}
}
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Teacher obj=new Teacher();
		System.out.println("\n------------------------------------");
		//CollegeStudent obj1=new CollegeStudent();
	}

}
