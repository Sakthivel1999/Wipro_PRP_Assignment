
 class Person  {
	 String Name="sakthi";
	 Person(){
		 System.out.println("Name:"+Name);
	 }

}
