import java.util.Scanner;
/*Create a class Box that uses a parameterized method to initialize the dimensions of a box.(dimensions are width, height, depth of double type). The class should have a method that can return volume. Obtain an object and print the corresponding volume in main() function*/
class Box{
	double dimensions(double width, double height, double depth ){
		double volume=width*height*depth;
		return volume;
	}
}
public class A1  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Value Of Width:");
		double width=scan.nextDouble();
		System.out.println("Enter The Value Of Height:");
		double height=scan.nextDouble();
		System.out.println("Enter The Value Of Depth");
		double depth=scan.nextDouble();
		Box obj=new Box();
		obj.dimensions(width, height, depth);
		System.out.println("Corresponding volume "+obj.dimensions(width, height, depth));
		scan.close();
	}

}
