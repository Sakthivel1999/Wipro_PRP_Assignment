abstract class A{
	//private String Name="sakthi";
	 int mark=90;
	
	abstract void compute();
}

class B extends A{
	void compute(){
		System.out.println(mark);
	}
}
public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj=new B();
		obj.compute();
		
	}

}
