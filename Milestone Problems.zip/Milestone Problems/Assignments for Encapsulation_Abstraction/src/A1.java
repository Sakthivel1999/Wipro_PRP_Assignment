import java.util.Scanner;

class Author{
	Scanner scan=new Scanner(System.in);
	private String Name="";
	private String email="";
	private char gender;
	Author(){
		String Name="sakthi";
		String email="sakthivels1613072@gmail.com";
		char gender='m';
		
		
	}
	void getName(){
		System.out.println("Enter The Author Name");
		Name=scan.nextLine();
	}
	
}
class Book {
	Scanner scan=new Scanner(System.in);
	private String Name="";
	private String author ="";
	private double price;
	private int qtyInStock;
	void getName(){
		System.out.println("Enter The Book Name");
		Name=scan.nextLine();
	}
	void getAuthor(){
		System.out.println("Author Name");
		author=scan.nextLine();
	}
	void getPrice(){
		System.out.println("Price Of Book");
		price=scan.nextDouble();
	}
	void setPrice(){
		System.out.println("Set Price");
		price=scan.nextDouble();
	}
	void getQtyInStock(){
		System.out.println("getQtyInStock");
		qtyInStock=scan.nextInt();
	}
	void setQtyInStock(){
		System.out.println("setQtyInStock");
		qtyInStock=scan.nextInt();
	}
	void Display(){
		System.out.println("book name="+Name);
		System.out.println("price="+price);
		System.out.println("qtyInStock="+qtyInStock);
	}
}
public class A1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book obj = new Book();
		obj.getName();
		obj.getAuthor();
		obj.getPrice();
		obj.setPrice();
		obj.getQtyInStock();
		obj.setQtyInStock();
		obj.Display();
		Author obj1=new Author();
		obj1.getName();
		
	}

}
