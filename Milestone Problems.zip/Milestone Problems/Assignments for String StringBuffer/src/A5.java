import java.util.Scanner;
public class A5 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The String");
		String str=scan.nextLine();
		if(str.length()>2){
		System.out.println(str.substring(1, str.length()-1));
		scan.close();
		}else{
			System.out.println("length will be at least 2");
			main(new String[] {});
		}
	}

}
