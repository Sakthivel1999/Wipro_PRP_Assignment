import java.util.Scanner;

public class A7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The String:");
		String str=scan.nextLine().toLowerCase();
		char ch=str.charAt(0);
		char ch2=str.charAt(str.length()-1);
		if(ch == ch2){
			System.out.println("Output="+str.substring(1,str.length()-1));
		}else{
			System.out.println("Output="+str.substring(0,str.length()));
		}scan.close();
	}

}
