import java.util.Scanner;

public class A12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The 1St String:");
		String str=scan.nextLine();
		System.out.println("Enter The Number Of Copies:");
		int n=scan.nextInt();
		for (int i = 0; i < n; i++) {
			System.out.print(str.substring(str.length()-n, str.length()));
		}scan.close();
	}

}
