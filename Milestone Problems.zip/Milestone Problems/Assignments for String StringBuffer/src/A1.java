import java.util.Scanner;

public class A1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The String:");
		String str=scan.nextLine();
		String temp=str;
		StringBuffer str1=new StringBuffer(str);
		StringBuffer s=str1.reverse();
		String a=s.toString();
		if(temp.equalsIgnoreCase(a)){
			System.out.println(temp+" Is Palindrome ");
		}else{
			System.out.println(temp+" Is Not Palindrome");
		}scan.close();
	}

}
