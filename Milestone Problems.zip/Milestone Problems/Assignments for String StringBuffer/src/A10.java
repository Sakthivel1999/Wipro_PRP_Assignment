import java.util.Scanner;

public class A10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The 1St String:");
		String str=scan.nextLine();
		System.out.println("Enter The 2Nd string:");
		String str1=scan.nextLine();
		if(str1.length()>str.length()){
			for (int i = 0; i < str.length(); i++) {
				System.out.print(str1.charAt(i)+""+str.charAt(i));
			}
		}else{
			for (int i = 0; i < str1.length(); i++) {
				System.out.print(str.charAt(i)+""+str1.charAt(i));
			}
		}scan.close();
	}

}
