import java.util.Scanner;

public class A8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The 1St String:");
		String str=scan.nextLine();
		System.out.println("Enter The 2Nd String");
		String str1=scan.nextLine();
		System.out.println("Enter The Number Of Copies:");
		int n=scan.nextInt();
		for (int i = 0; i <n; i++) {
			System.out.print(str.concat(str1));
		}scan.close();
	}

}
