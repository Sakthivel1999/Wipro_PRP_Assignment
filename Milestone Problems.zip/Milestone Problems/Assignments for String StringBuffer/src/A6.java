import java.util.Scanner;

public class A6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The 1st String:");
		String str=scan.nextLine();
		System.out.println("Enter The 2Nd String:");
		String  str1=scan.nextLine();
		if(str.length()<str1.length()){
			System.out.println(str+" "+str1+" "+str);
		}if(str.length()>str1.length()){
			System.out.println(str1+" "+str+" "+str1);
		}else{
			if(str.length()==str1.length()){
				System.out.println("Both are Equals");
				main(new String[] {});
			}
		}scan.close();
	}

}
