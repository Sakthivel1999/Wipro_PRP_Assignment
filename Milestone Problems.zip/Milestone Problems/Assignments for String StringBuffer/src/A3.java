import java.util.Scanner;

public class A3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The String:");
		String str=scan.nextLine();
		char ch=str.charAt(0);
		char ch1=str.charAt(1);
		System.out.println("Enter The Number Of Copies:");
		int n=scan.nextInt();
		for (int i = 0; i <n; i++) {
			System.out.print(ch+""+ch1);
		}
		scan.close();
	}

}
