import java.util.Scanner;

public class A13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The String:");
		String str=scan.nextLine().toLowerCase();
		StringBuffer str1=new StringBuffer(str);
		StringBuffer output=new StringBuffer();
		if(str.indexOf("xy") <2){
			str1.delete(0, 2);
			//System.out.println(str1);
			String s=str1.toString();
			if(s.contains("xy")){
				//System.out.println(s.indexOf("xy"));
				for (int i = s.indexOf("xy"); i < s.length();) {
					output.append(s.charAt(0)+""+s.charAt(i-1));
					System.out.println("Output="+output);
					break;
				}
			}
			
		}else{
			if(str.contains("xy")==true ){
				for (int i = str.indexOf("xy"); i < str.length();) {
					output.append(str.charAt(i-1)+""+(str.charAt(i+2)));
					break;
				}
			}
			
			str1.delete(str.indexOf("xy"),str.indexOf("xy")+1);
			//System.out.println(str1);
			String str2=str1.toString();
			if(str2.contains("xy")==true ){
				for (int i = str2.indexOf("xy"); i < str2.length();) {
					output.append((str2.charAt(i-1)+""+(str2.charAt(i+2))));
					break;
				}
			}
			System.out.println("Output="+output);
		}
		
		scan.close();
		//abcXY123XYijk
		//XY123XY
		//XY1XY
	}

}
