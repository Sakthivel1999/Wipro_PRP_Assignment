import java.util.Scanner;

public class A9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The String:");
		String str=scan.nextLine();
		StringBuffer str1=new StringBuffer(str);
		
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i)=='*' && str.charAt(i+1)=='*'){
			str1.deleteCharAt(i-1);
			str1.deleteCharAt(i-1);
			str1.deleteCharAt(i-1);
			str1.deleteCharAt(i-1);
			break;
			}else{
				if(str.charAt(i)=='*'){
					str1.deleteCharAt(i-1);
					str1.deleteCharAt(i-1);
					str1.deleteCharAt(i-1);
					break;
				}
			}
		}
		System.out.println(str1);
		scan.close();
	}

}
