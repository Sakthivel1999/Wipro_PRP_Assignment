import java.util.Scanner;

public class A2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The First String:");
		String str=scan.nextLine().toLowerCase();
		System.out.println("Enter The 2Nd String:");
		String str1=scan.nextLine().toLowerCase();
		char ch=str.charAt(str.length()-1);
		char ch1=str1.charAt(0);
		if(ch == ch1){
			int len=str1.length();
			String str3=str1.substring(1, len);
			String result=str.concat(str3);
			System.out.println(result);
		}else{
			System.out.println(str.concat(str1));
		}scan.close();
	}

}
