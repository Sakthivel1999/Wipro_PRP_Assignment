import java.util.Scanner;

public class A4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Even Length String:");
		String str=scan.nextLine();
		if(str.length()%2 == 0){
			int len=str.length()/2;
			System.out.println(str.substring(0, len));
		}else{
			System.out.println("Null");
			main(new String [] {});
		}scan.close();
	}

}
