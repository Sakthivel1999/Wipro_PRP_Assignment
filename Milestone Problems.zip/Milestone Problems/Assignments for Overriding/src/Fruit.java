class Apple{
	String fruit_name="apple";
	String taste="sweety";
	int size=2;
	void eat(){
		System.out.println("Apple");
	}
}
class Orange extends Apple{
	
	void eat(){
		System.out.println("Orange");
	}
}
public class Fruit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Apple obj=new Apple();
		obj.eat();
		Apple obj1=new Orange();
		obj1.eat();
	}

}
