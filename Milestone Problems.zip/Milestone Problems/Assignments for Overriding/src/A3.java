

class shape{
	void draw(){
		System.out.println("Drawing Shape");
	}
	void erase(){
	System.out.println("Erasing Shape");
	}
}
class Circle extends shape{
	void draw(){
		System.out.println("Drawing Circle");
	}
	void erase(){
	System.out.println("Erasing Circle");
	}
}

class Triangle extends shape{
	void draw(){
		System.out.println("Drawing Triangle");
	}
	void erase(){
	System.out.println("Erasing Triangle");
	}
}

class Square extends shape{
	void draw(){
		System.out.println("Drawing Square");
	}
	void erase(){
	System.out.println("Erasing Square");
	}
}



public class A3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		shape obj=new Circle();
		obj.draw();	
		shape obj1=new Triangle();
		obj1.draw();
		shape obj2=new Square();
		obj2.draw();
		System.out.println("---------------");	
		obj.erase();
		obj1.erase();
		obj2.erase();
	}

}
