/*  Write a program to initialize an integer array and find the maximum and minimum value of an array */
package ass3;
import java.util.*;
public class A25 {
public static void main(String[] arg)
	{
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the length of array:");
	int n=scan.nextInt();
	int[] a=new int[n];
	int max=a[0];
	int min=a[0];
	System.out.println("Enter the elements for array");
	for(int i=0;i<n;i++)
		a[i]=scan.nextInt();
	for(int i=0;i<n-1;i++)
	{
		if(Math.max(max,a[i+1])>max)
			max=a[i+1];
	}
	System.out.println("Maximum value of array:"+max);
	for(int i=0;i<n-1;i++) 
	{
		if(Math.min(min,a[i+1])<min)
			min=a[i+1];
	}
	System.out.println("Minimum value of array:"+min);
	} 
}
