/* Write a program to print the sum of the elements of the array with the given below condition. If the array has 6 and 7 in succeeding orders, ignore 6 and 7 and the numbers between them for the calculation of sum. Eg1) Array Elements - 10,3,6,1,2,7,9 O/P: 22    [i.e 10+3+9] Eg2) Array Elements - 7,1,2,3,6 O/P:19 Eg3) Array Elements - 1,6,4,7,9 O/P:10 */
package ass3;
import java.util.*;
public class A32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scan=new Scanner(System.in);
		   System.out.println("Enter the length of array:");
			int n=scan.nextInt();
			int[] ar=new int[n];
			int sum=0;
			System.out.println("Enter elements for the array");
			for(int i=0;i<n;i++)
				ar[i]=scan.nextInt();
			for(int i=0;i<n;i++)
			{
			  if(ar[i]==6)
			  {
				  for(int j=i+1;j<n;j++)
					  if(ar[j]==7)
						  for(int k=j;k>=i;k--)
							  ar[k]=0;
			  }
			  sum=sum+ar[i];
			}
			System.out.println(sum);
	}

}
