/* Write a program to initialize an array and print them in a sorted fashion */
package ass3;
import java.util.*;
public class A29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the length of array:");
		int n=scan.nextInt();
		int m[]= new int[n];
		int temp=0;
		System.out.println("Enter elenents for the array");
		for(int i=0;i<m.length;i++)
			m[i]=scan.nextInt();
		for(int i=0;i<m.length-1;i++)
		{
		for(int j=i+1;j<m.length;j++)
			if(m[i]>m[j])
			   {temp=m[i];
			    m[i]=m[j];
			    m[j]=temp;}
		System.out.println(m[i]);
		}
	}

}
