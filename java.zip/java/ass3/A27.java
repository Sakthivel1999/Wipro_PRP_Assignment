/*Initialize an integer array with ascii values and print the corresponding character values in a single row. */
package ass3;

public class A27 {
	public static void main(String[] args) {
		int arr[]=new int[] {67,97,65,98,102};
		for(int i=0;i<arr.length;i++)
		{
		System.out.print((char)arr[i]+" ");
		}
	}

}
