/* Write a program to print the element of an array that has occurred the highest number of times Eg) Array -> 10,20,10,30,40,100,99 O/P:10 
 */

package ass3;
import java.util.*;
public class A31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		  System.out.println("Enter the length of array:");
		   int n=scan.nextInt();
		   int max, count;
		   max = count = 0;
		  System.out.println("Enter the elements for array:");
		 int[] a= new int[n];
		 for (int i = 0; i < n; i++)
			a[i]=scan.nextInt();
		 for (int i = 0; i <n; i++) {
			int temp = 0;
			for (int j = 0; j <n; j++) {
				if (a[i] == a[j]) {
					temp++;
				}
			}
			if (temp > count) {
				max = a[i];
				count = temp;
			}
		}
		System.out.println("p = " + max);
	}

}
