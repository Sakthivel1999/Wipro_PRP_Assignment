/* Write a program to reverse the elements of a given 2*2 array. Four integer numbers needs to be passed as Command Line arguments. 
 
Example1: 
 
     C:\>java Sample 1 2 3 
 
     O/P Expected : Please enter 4 integer numbers 
 
Example2: 
 
     C:\>java Sample 1 2 3 4 
 
     O/P Expected :          The given array is :   1 2    3 4    The reverse of the array is :   4 3    2 1 
 
1       2         3       4 5       6         7       8 9       10       11     12 
 */
package ass3;

public class A33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length>3)
		{
		int no1=Integer.parseInt(args[0]);
		int no2=Integer.parseInt(args[1]);
		int no3=Integer.parseInt(args[2]);
		int no4=Integer.parseInt(args[3]);
		int[][] arr=new int[][] {{no1,no2},{no3,no4}};
		int newArr[][]=new int[2][2];
		for(int i=1;i>=0;i--)
		{
			for(int j=1;j>=0;j--)
			{
				newArr[i][j]=arr[i][j];
				System.out.print(newArr[i][j]+" ");
			}
			System.out.println();
		}
		}
		else
			System.out.println("Please enter 4 integer numbers");
	}

}
