/*  Write a program to initialize an integer array and print the sum and average of the array */
package ass3;

public class A24 {

	public static void main(String[] args) {
		int a[]=new int[]{1,2,3,4,5};
		int add=0;
		for(int i=0;i<a.length;i++)
		{
		add=add+a[i];
		}
		System.out.println(add/a.length);

	}

}
