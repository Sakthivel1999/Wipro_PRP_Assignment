/* Write a program to remove the duplicate elements in an array and print Eg) Array Elements--12,34,12,45,67,89 O/P: 12,34,45,67,89 
 */
package ass3;
import java.util.*;
public class A30 {
public static void main(String[] args) {
		// TODO Auto-generated method stub
	int arr[]=new int[] {12,34,12,45,67,89};
	int len=arr.length;
	for(int i=0;i<len;i++)
	{
		for(int j=i+1;j<len;j++)
		{
			if(arr[i]==arr[j])
			{
				int shift=j;
				for(int k=j+1;k<len;k++)
				{
					arr[shift]=arr[k];
				}
				len--;
				j--;
			}
		}
	}
	int arrDup[]=new int[len];
	for(int i=0;i<len;i++)
	{
		arrDup[i]=arr[i];
	}
	System.out.println(Arrays.toString(arrDup));
	}
}
