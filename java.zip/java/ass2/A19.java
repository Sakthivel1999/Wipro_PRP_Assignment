/* Write a program to print * in Floyds format (using for and while loop) 
 * * *  * *  *   * 
 
 
 
Example1: 
 
     C:\>java Sample  
 
     O/P Expected : Please enter an integer number 
 
Example1: 
 
     C:\>java Sample 3 
 
     O/P Expected :                    *                    *  *                     *  *  * */

package ass2;
import java.util.*;
public class A19 {
public static void main(String[] args) {
	System.out.println("Enter the size of n:");
	Scanner scan=new Scanner(System.in);
	int n=scan.nextInt();
	for(int i=0;i<n;i++) {
		for(int j=0;j<=i;j++) 
			System.out.print("*");
			System.out.println();
	}
}
}

		
	