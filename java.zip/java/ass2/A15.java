/* Write a program to check if a given number is prime or not  */

package ass2;
import java.util.*;
public class A15 {
public static void main(String[] args) {
	System.out.println("Enter the Number");
	Scanner scan=new Scanner(System.in);
	int number=scan.nextInt();
    boolean flag = false;
    for(int i=2; i <= number/2; i++)
    {
        if(number % i == 0)
        {
            flag = true;
            break;
        }
    }

    if (!flag)
        System.out.println("prime number:" +number);
    else
        System.out.println("not a prime number:" +number);
}
}
