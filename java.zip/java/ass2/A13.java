/* Write a program to print numbers from 1 to 10 in a single row with one tab space.  */

package ass2;
import java.util.*;
public class A13 {
public static void main(String[] args) {
	System.out.println("Enter the value of n:");
	Scanner scan=new Scanner(System.in);
	int n=scan.nextInt();
	for(int i=0;i<=n;i++) {
		System.out.print(i+ "\t");
	}
}
}
