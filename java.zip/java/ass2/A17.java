/*
 *  Write a Java program to find if the given number is prime or not. 
 
Example1: 
 
     C:\>java Sample  
 
     O/P Expected : Please enter an integer number  
 
Example2: 
 
     C:\>java Sample 1 
 
     O/P Expected : 1 is neither prime nor composite 
 
Example3: 
 
     C:\>java Sample 0 
 
     O/P Expected : 0 is neither prime nor composite    Example4: 
 
     C:\>java Sample 10 
 
     O/P Expected : 10 is not a prime number 
 
Example5: 
 
     C:\>java Sample 7 
 
     O/P Expected : 7 is a prime number  */

package ass2;

public class A17 {
	public static void main(String[] args) {
		  int n=  Integer.parseInt(args[0]);
		 if(n<0){
			 System.out.println("the number is negative");
		 }else if(n==0||n==1){
				 System.out.println(n+" is neither prime nor composite" );
		 }else{
			 boolean flag=true;
		      for(int i=2;i<n;i++){
		    	  if(n%i==0){
		    		   flag=false;
		    		   break;
		    	  }
		    	  
		      }
		      if(flag==true){
		    	  System.out.println(n+" it is prime number");
		      }else{
		    	  System.out.println(n+" it is not prime number");
		      }
		 }
	}
}
