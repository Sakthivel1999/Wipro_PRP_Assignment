/*  Write a program to check if the program has received command line arguments or not. If the program has not received the values then print "No Values", else print all the values in a single line separated by ,(comma). Eg1) java Example O/P: No values Eg2) java Example Mumbai Bangalore O/P: Mumbai,Bangalore [Note: You can use length property of an array to check its length 
 */
package ass2;
import java.util.*;
public class A6 {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	char a=scan.next().charAt(0);
	char b=scan.next().charAt(0);
	if(a>b) {
		System.out.println(b+","+a);
	}else{
		System.out.println(a + "," +b);
	}
	scan.close();
}
}
