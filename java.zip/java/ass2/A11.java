/*  Write a program to print the color name, based on color code. If color code in not valid then print "Invalid Code". R->Red, B->Blue, G->Green, O->Orange, Y->Yellow, W->White. */

package ass2;
import java.util.*;
public class A11 {
	public static void main(String[] args) {
		System.out.println("Enter your choice:");
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		switch(a) {
		case 1:
			System.out.println("Red");
			break;
		case 2:
			System.out.println("Blue");
			break;
		case 3:
			System.out.println("Green");
			break;
		case 4:
			System.out.println("Orange");
			break;
		case 5:
			System.out.println("Yellow");
			break;
		case 6:
			System.out.println("White");
			break;
		}
	}
}
