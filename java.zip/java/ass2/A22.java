/*  Write a program to print first 5 values which are divisible by 2, 3, and 5. */

package ass2;

public class A22 {

	public static void main(String[] args) {
		int a=1,count=0;
		while(count<5) {
		if(a%2==0 && a%3==0 && a%5==0) {
		System.out.println(a);
		count++;
		}
		a++;
		}
		

	}

}
