/*  Write a program to convert from upper case to lower case and vice versa of an alphabet and print the old character and new character as shown in example (Ex: a->A, M->m). */

package ass2;
import java.util.*;
public class A10 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
	     String  a=scan.nextLine();
		 String c= a.toUpperCase();
		System.out.println(c);		
		}
	}