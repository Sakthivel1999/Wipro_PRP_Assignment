/* Write a program to print even numbers between 23 and 57, each number should be printed in a separate row. */

package ass2;

public class A14 {

	public static void main(String[] args) {
		System.out.println("Even Number Is");
		for(int i=23;i<=57;i++) {
			int c=(i%2);
		
			if(c==0) {
				System.out.print(i + "\t");
			}
		}
		

	}

}
