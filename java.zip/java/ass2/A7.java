/* Initialize two character variables in a program and display the characters in alphabetical order. Eg1) if first character is s and second is e O/P: e,s Eg2) if first character is a and second is e O/P:a,e 
  */

package ass2;

public class A7 {
	public static void main(String[] args) {
		System.out.println("Enter the string:");

		if(args.length==0) {
			System.out.println("no value");
		}
		for(int i=1;i<args.length;i++) {
			System.out.println(args[0] +"," +args[1]);
		}
	}
}
