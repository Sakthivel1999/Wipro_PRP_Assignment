/*Write a program that displays a menu with options 1. Add 2. Sub Based on the options chosen, read 2 numbers and perform the relevant operation. After performing the operation, the program should ask the user if he wants to continue. If the user presses y or Y, then the program should continue displaying the menu else the program should terminate. [ Note: Use Scanner class, you can take help from the trainer regarding the same ]  */

package ass2;
import java.util.*;
public class A23 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		char enter='n';
		do {
			System.out.println("1.Add");
			System.out.println("2.Sub");
			int option=scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter the two number: ");
				int a=scan.nextInt();
				int b=scan.nextInt();
				System.out.println("Addition: "+(a+b));
				break;
			case 2:
				System.out.println("Enter the two number: ");
				int c=scan.nextInt();
				int d=scan.nextInt();
				System.out.println("Addition: "+(c-d));
				break;

			default:
				System.out.println("Enter the given option.....");
				break;
			}
			System.out.println("Do u want to continue press Y or y.....");
			enter=scan.next().charAt(0);
		} while (enter=='y'||enter=='Y');
	}

	}


