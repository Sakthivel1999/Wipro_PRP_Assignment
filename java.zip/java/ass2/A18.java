/*  Write a program to add all the values in a given number and print. Ex: 1234->10*/

package ass2;
import java.util.*;
public class A18 {

	public static void main(String[] args) {
		System.out.println("Enter the size of n:");
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		int total=0;
		int num=0;
		while(n!=0) {
			num=n%10;
			total=total+num;
			n=n/10;
		}
		System.out.println(total);
	}

}
