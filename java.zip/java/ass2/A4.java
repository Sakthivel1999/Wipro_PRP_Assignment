/* Write a program to check if a given number is Positive, Negative, or Zero.  */

package ass2;
import java.util.*;
public class A4 {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	int a=s.nextInt();
	if(a<0) {
		System.out.println("negative");
	}else if(a>0) {
		System.out.println("positive");
	}else if(a==0) {
		System.out.println("Zero");

	}
	

}
}
