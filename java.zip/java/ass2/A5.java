/*  Write a program to check if a given number is odd or even. */

package ass2;
import java.util.*;
public class A5 {
	public static void main(String[] args) {
		System.out.println("Enter the number of a:");
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		if(a%2 == 0) {
			System.out.println("Even");
		}else if(a%2 == 1) {
			System.out.println("Odd");
		}
	}

}
