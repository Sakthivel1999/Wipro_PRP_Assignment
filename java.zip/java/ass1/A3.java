/*  Write a Program to accept two integers through the command line  argument and print the sum of the two numbers 
 
Example: 
 
     C:\>java Sample 10 20 
 
     O/P Expected : The sum of 10 and 20 is 30 Write a Program to accept two integers through the command line  argument and print the sum of the two numbers 
 
Example: 
 
     C:\>java Sample 10 20 
 
     O/P Expected : The sum of 10 and 20 is 30 */

package ass1;
import java.util.*;
public class A3 {

	public static void main(String[] args) {
				Scanner scan=new Scanner(System.in);
				int a=scan.nextInt();
				int b=scan.nextInt();
				System.out.println("Sum of two int value" + a+b);

	}

}
